declare module 'bsv';
declare module 'bitcore-mnemonic';
